package com.mercy;

import com.mercy.process.CoProcessEnrichRule;
import com.mercy.process.CoProcessIndicatorRule;
import com.mercy.process.FsAlarmDivideProcess;

import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) throws Exception {
        final long startTime = System.currentTimeMillis();
        StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironment();

        DataStreamSource<Integer> rawAlarmSrc = env.addSource(new IntegerSource("rawalarm", startTime));
        DataStreamSource<Integer> enrichSrc = env.addSource(new IntegerSource("enrichrule", startTime));
        DataStreamSource<Integer> indicatorSrc = env.addSource(new IntegerSource("indicatorrule", startTime));

        SingleOutputStreamOperator<Integer> fsAlarmStream = rawAlarmSrc.process(new FsAlarmDivideProcess());

        DataStream<Integer> NonFsAlarmStream = fsAlarmStream.getSideOutput(new OutputTag<Integer>("NonFsAlarm"));

        // FS告警流连接增维规则
        SingleOutputStreamOperator<Integer> eventStream = fsAlarmStream.connect(enrichSrc)
                .process(new CoProcessEnrichRule());

        // 构建NonEvent 流
        DataStream<Integer> nonEventStream = eventStream.getSideOutput(new OutputTag<Integer>("NonEvent"));

        SingleOutputStreamOperator<Integer> sinkEventStream = eventStream.connect(indicatorSrc)
                .process(new CoProcessIndicatorRule());

        DataStream<Integer> nonIndicatorEventStream = eventStream
                .getSideOutput(new OutputTag<Integer>("NonIndicatorEvent"));

        /*
         * 直接告警
         */
        // 告警流连接 NonEvent 广播流
        NonFsAlarmStream.connect(nonEventStream.broadcast())
                .process(new CoProcessFunction<Integer, Integer, Integer>() {

                    @Override
                    public void processElement1(Integer alarm, CoProcessFunction<Integer, Integer, Integer>.Context ctx,
                            Collector<Integer> out) throws Exception {
                        out.collect(alarm);
                    }

                    @Override
                    public void processElement2(Integer nonEvent,
                            CoProcessFunction<Integer, Integer, Integer>.Context ctx,
                            Collector<Integer> out) throws Exception {
                        // TODO NonEvent To alarm
                        out.collect(nonEvent);
                    }

                });

        // 告警流连接 未命中规则的事件流 广播流
        NonFsAlarmStream.connect(nonIndicatorEventStream)
                .process(new CoProcessFunction<Integer, Integer, Integer>() {

                    @Override
                    public void processElement1(Integer alarm, CoProcessFunction<Integer, Integer, Integer>.Context ctx,
                            Collector<Integer> out) throws Exception {
                        out.collect(alarm);
                    }

                    @Override
                    public void processElement2(Integer nonIndicatorEvent,
                            CoProcessFunction<Integer, Integer, Integer>.Context ctx,
                            Collector<Integer> out) throws Exception {
                        out.collect(nonIndicatorEvent);
                    }

                })
                // .addSink()
                .print();

        // sinkEventStream.addSink()
        // nonEventStream.addSink()
        nonEventStream.print();
        sinkEventStream.print();

        env.execute();
    }
}
