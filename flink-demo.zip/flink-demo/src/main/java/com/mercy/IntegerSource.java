package com.mercy;

import org.apache.flink.streaming.api.functions.source.SourceFunction;

import akka.actor.dsl.Inbox.Select;

public class IntegerSource implements SourceFunction<Integer> {

    long startTime;
    String sourceType;

    public IntegerSource(String sourceType, long startTime) {
        this.startTime = startTime;
        this.sourceType = sourceType;
    }

    public void run(SourceContext<Integer> ctx) throws Exception {
        while (startTime + (10 * 1000) > System.currentTimeMillis()) {

            if (sourceType.equals("rawalarm")) {
                int v = (int) (Math.random() * 10);
                ctx.collect(v);
            } else if (sourceType.equals("enrichrule")) {
                ctx.collect(Integer.valueOf(10));
            } else if (sourceType.equals("indicatorrule")) {
                ctx.collect(Integer.valueOf(20));
            }
            Thread.sleep(500);
        }
        ctx.close();
    }

    public void cancel() {
        System.out.println("Close");
    }

}
