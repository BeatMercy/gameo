package com.mercy.process;

import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

public class FsAlarmDivideProcess extends ProcessFunction<Integer, Integer> {

    @Override
    public void processElement(Integer value, Context ctx, Collector<Integer> out)
            throws Exception {
        if (value > 7) {
            // 分流非FS告警
            ctx.output(new OutputTag<Integer>("NonFsAlarm"), value);
        } else {
            out.collect(value);
        }
    }

}
