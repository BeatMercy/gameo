package com.mercy.process;

import java.util.ArrayList;
import java.util.List;

import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.co.CoProcessFunction;
import org.apache.flink.util.OutputTag;
import org.apache.flink.util.Collector;

public class CoProcessIndicatorRule extends CoProcessFunction<Integer, Integer, Integer> {

    ValueState<List<Integer>> indicators;

    @Override
    public void open(Configuration parameters) throws Exception {
        // TODO 初始化indicators
        super.open(parameters);
    }

    @Override
    public void processElement1(Integer alarm, Context ctx, Collector<Integer> out) throws Exception {
        if (indicators.value() == null || indicators.value().size() == 0) {
            // 未配置增维规则。都作为NonEvent输出
            // 增维失败事件
            ctx.output(new OutputTag<Integer>("NoIndicatorEvent"), alarm);
            return;
        }

        // 比较规则
        for (Integer rule : indicators.value()) {
            if (rule > alarm) {
                // 增维失败事件
                ctx.output(new OutputTag<Integer>("NoIndicatorEvent"), alarm);
            } else {
                out.collect(alarm);
            }
        }

    }

    // 更新规则流
    @Override
    public void processElement2(Integer enrichRule, Context ctx,
            Collector<Integer> out) throws Exception {
        if (indicators.value() == null || indicators.value().size() == 0) {
            indicators.update(new ArrayList<Integer>());
        }
        indicators.value().add(enrichRule);
    }

}
