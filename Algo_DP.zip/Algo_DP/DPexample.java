package Algo_DP;

public class DPexample {

    public static void main(String[] args) {
        System.out.println(dp(7));
    }

    static int dp(int arrayIndex) {
        int[] dp = new int[arrayIndex + 1];
        dp[1] = 1;
        dp[2] = 1;
        for (int i = 3; i < arrayIndex + 1; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
        }
        return dp[arrayIndex];
    }
}
