package Algo_DP;

import java.nio.file.spi.FileSystemProvider;

// https://leetcode.cn/problems/house-robber/
public class DaJiaJieShe {

    public static void main(String[] args) {
        int[][] inputs = new int[][] {
                new int[] { 1, 23, 4, 5, 5, 7, 8, 8, 9, 2 }
        };
        System.out.println(new DaJiaJieShe().rob(inputs[0]));
        System.out.println(new DaJiaJieShe().dpOn(inputs[0]));
        System.out.println(new DaJiaJieShe().dpO1(inputs[0]));
    }
    // nums.length = n
    // 1、i = 0 若 偷， 1 不可偷，则等价计算 n-2 中最大值
    // 2、i = 0 若 不偷， 1 可偷，则等价计算 n-1 中最大值
    // 3、i = 1 若 偷， 2 不可偷，则等价计算 n-3 中最大值
    // 4、i = 1 若 不偷， 2 可偷，则等价计算 n-2 中最大值
    // 5、i = 2 若 偷， 3 不可偷，则等价计算 n-4 中最大值
    // 6、i = 2 若 不偷， 3 可偷，则等价计算 n-3 中最大值

    // 1 -> 4 -> 5, 1 -> 4 -> 6,  2 -> 3 -> 6 ... 求其中的Max排列
    int[] used;

    public int rob(int[] nums) {
        int n = nums.length;
        used = new int[n];
        return dfs(nums, n - 1);
    }

    public int dfs(int[] nums, int i) {
        if (i < 0) {
            return 0;
        }
        if (used[i] != 0) {
            return used[i];
        }
        // i-1 代表 i 相邻被盗窃，i不可以盗窃
        // i-2 代表 i 相邻未被盗窃，i可以盗窃
        // 取两种情况下的最值为结果

        int robMax = Math.max(dfs(nums, i - 1), dfs(nums, i - 2) + nums[i]); // 值计算一次 计算复杂度 O(n)
        used[i] = robMax; // 空间需要 O(n)
        return robMax;
    }

    //  int robMax = Math.max(dfs(nums, i - 1), dfs(nums, i - 2) + nums[i]);
    // => f[i] =  max(f[i-1], f[i-2] + nums[i])
    // => f[i+2] = max(f[i+1], f[i] + nums[i+2])
    // 自下而上递推
    public int dpOn(int[] nums) {
        int[] dp = new int[nums.length + 2];
        for (int i = 2; i < nums.length + 2; i++) {
            dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i - 2]);
        }
        return dp[dp.length - 1];
    }

    public int dpO1(int[] nums) {
        int pre1 = 0;
        int pre2 = 0;
        int res = 0;
        for (int i = 0; i < nums.length; i++) {
            // dp[i] = Math.max(dp[i - 1], dp[i - 2] + nums[i - 2]);
            res = Math.max(pre1, pre2 + nums[i]);
            pre2 = pre1;
            pre1 = res;
        }
        return res;
    }

}
