package Algo_DP;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ChangeWithCost {

    public int changeWithCost(int expected) {
        if (expected <= 3) {
            return expected * 5;
        }
        int cost = 0;
        int cur = 0;
        for (int i = 1; i <= expected; i++) {
            cost += 5;
            cur++;
            if (cur == 3) {
                cur = 1;
                cost += 1;
                i++;
            }
        }
        return cost;
    }

    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in, StandardCharsets.UTF_8.name());
        Integer expected = cin.nextInt();
        System.out.println(new ChangeWithCost().changeWithCost(expected));
    }

}
