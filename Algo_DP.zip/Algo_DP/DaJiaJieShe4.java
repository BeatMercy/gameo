package Algo_DP;

import java.nio.file.spi.FileSystemProvider;

// https://leetcode.cn/problems/house-robber/
public class DaJiaJieShe4 {

    public static void main(String[] args) {
        int[][] inputs = new int[][] {
                new int[] { 2, 3, 5, 9 },
                new int[] { 2, 7, 9, 3, 1 }
        };
        System.out.println(new DaJiaJieShe4().minCapability(inputs[0], 2));
        System.out.println(new DaJiaJieShe4().minCapability(inputs[1], 2));
    }

    public int minCapability(int[] nums, int k) {
        // 题目：1 <= nums[i] <= 109
        int left = 1;
        int right = 0;
        for (int i = 0; i < nums.length; i++) {
            right = Math.max(nums[i], right);
        }
        while (left <= right) {
            int mid = left + (right - left) / 2;

            // 计算金额达到 >=mid 金额最多要几个房子
            int maxSteal = calMaxHouseSteal(nums, mid);
            if (k <= maxSteal) {
                // 所需房子小于等于题目要求k，需要减少金额目标 拟近 最小的最大偷取金额值
                right = mid - 1;
            } else {
                // 所需房子大于题目要求k，需要增加金额目标
                left = mid + 1;
            }
        }
        return left;
    }

    public int calMaxHouseSteal(int[] nums, int target) {
        int[] dp = new int[nums.length + 2];// 偷前i个房子，所有房子中，任一单间不超过target，最多可以偷多少个房子
        for (int i = 0; i < nums.length; i++) {
            int total = nums[i];
            dp[i + 2] = dp[i + 1]; // i+1 偷了，i+2 没法偷，所以房数不会变化
            if (total <= target) { // 超过猜测的目标值，符合题目要求，进入下一轮求具体最大值
                dp[i + 2] = Math.max(dp[i + 1], dp[i] + 1);
            }
        }
        return dp[nums.length - 1 + 2];
    }
}
